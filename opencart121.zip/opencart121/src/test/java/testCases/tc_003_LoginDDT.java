package testCases;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import pageObjects.LoginPage;
import pageObjects.MyAccountPage;
import testBase.BaseClass;
import utilities.DataProviders;

public class tc_003_LoginDDT extends BaseClass{

	@Test(dataProvider="LoginData",dataProviderClass=DataProviders.class)//getting data provider from different class.
	public void verify_loginDDT(String email,String pwd,String exp)
	{
        try {
		//Home page
		HomePage hp=new HomePage(driver);
		hp.clikcMyAccount();
		logger.info("MY ACCOUNT  button clicked--");
		hp.clickLogin();
		logger.info("LOGIN OPTION button clicked--");
		
		//Login page
		LoginPage lp=new LoginPage(driver);
		lp.setEmail(email);
		lp.setPassword(pwd);
		lp.clickLogin();
		logger.info("login button clicked--");
		
		//My Account page
		MyAccountPage map=new MyAccountPage(driver);
		boolean targetPage=map.isMyAccountPageExists();
				
				//conditions
				if(exp.equalsIgnoreCase("valid")) 
				{
					if(targetPage==true)
					{
						map.clickLogout();
						Assert.assertTrue(true);
					}
					else
					{
						Assert.assertTrue(false);
					}
				}
				if(exp.equalsIgnoreCase("invalid"))
				{
					if(targetPage==true)
					{
						map.clickLogout();
						Assert.assertTrue(false);
					}
					else
					{
						Assert.assertTrue(true);//login not successfull.
					}
				}
    	}//try
	
	catch(Exception e)
	{
		Assert.fail();
	}
	logger.info("****Finished_tc_003_LoginDDT****");
 
 }//method
}//class
