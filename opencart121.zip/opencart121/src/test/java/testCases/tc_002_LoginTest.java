package testCases;

import java.time.Duration;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import pageObjects.LoginPage;
import pageObjects.MyAccountPage;
import testBase.BaseClass;

public class tc_002_LoginTest extends BaseClass{

	@Test
	public void verify_login()
	{
		logger.info("****starting TC_002_LoginTest*****");
		
	try {
		//Home page
		HomePage hp=new HomePage(driver);
		
		hp.clikcMyAccount();
		//driver.findElement(By.id("alert")).click();
		logger.info("MY ACCOUNT  button clicked--");
		
		hp.clikcMyAccount();
		//Thread.sleep(4000);
		//human verification occurring here in the flow
		
		hp.clickLogin();
		logger.info("LOGIN OPTION button clicked--");
		
		//Login page
		LoginPage lp=new LoginPage(driver);
		System.out.println("email="+p.getProperty("email"));
		lp.setEmail(p.getProperty("email"));
		System.out.println("pwd="+p.getProperty("password"));
		lp.setPassword(p.getProperty("password"));
		lp.clickLogin();
		logger.info("login button clicked--");
		
		//My Account page
		MyAccountPage map=new MyAccountPage(driver);
		boolean targetPage=map.isMyAccountPageExists();
		Assert.assertTrue(targetPage);//Assert.assertEquals(targetPage, true,"Login failed");
		}
		catch(Exception e) 
	    {
			logger.info("EXCEPTION --"+e);
			System.out.println(e);
			Assert.fail();
		}
	  logger.info("****test finished****");
	}
}
