package testCases;

import java.time.Duration;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;
import pageObjects.AccountRegistrationPage;
import pageObjects.HomePage;
import testBase.BaseClass;

public class tc001_AccountRegistration extends BaseClass {
	@Test
	public void verify_account_registration() {
		
		
		logger.info("******starting TC_001test case*****");
	try {	
		HomePage hp=new HomePage(driver);
		hp.clikcMyAccount();
		logger.info("******my account clicked*****");
		
		hp.clikcRegister();
		logger.info("register link clicked....");
		
		AccountRegistrationPage arp=new AccountRegistrationPage(driver);
		logger.info("providing customer details");
		
		arp.setFirstname(randomString().toUpperCase());
		arp.setLastname(randomString().toUpperCase());
		arp.setEmail(randomString()+"@gmail.com");
		arp.setTelephone(randomNumber());
		
		String password=randomAlphanumeric();
		arp.setPassword(password);
		arp.setConfirmPassword(password);
		arp.clickAgree();
		arp.clickButton();
		
		logger.info("validating expected msg");
		String msg=arp.getConfirmationMsg();
		if(msg.equals("Your Account Has Been Created!"))
		{
			Assert.assertTrue(true);
		}
		else {
			logger.error("Test failed");
			logger.debug("Debug logs....");
			Assert.assertTrue(false);
		   }
	    
	   }
	  catch(Exception e) {
		   Assert.fail();
	   }
	 logger.info("******Finished TC_001test case*****");
	
	}
}
