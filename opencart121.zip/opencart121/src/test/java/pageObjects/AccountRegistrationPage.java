package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AccountRegistrationPage extends BasePage{

	public AccountRegistrationPage(WebDriver driver) {
		super(driver);
	   }

	@FindBy(xpath="//input[@id='input-firstname']") WebElement txtFirstname;
	@FindBy(xpath="//input[@id='input-lastname']") WebElement txtlastname;
	@FindBy(xpath="//input[@id='input-email']") WebElement txtEmail;
	@FindBy(xpath="//input[@id='input-telephone']") WebElement txtTelephone;
	@FindBy(	xpath="//input[@id='input-password']") WebElement txtPassword;
	@FindBy(xpath="//input[@id='input-confirm']") WebElement txtConfirmpassword;
	@FindBy(xpath="//input[@name='agree']") WebElement txtAgree;
	@FindBy(xpath="//input[@value='Continue']") WebElement btnContinue;
    @FindBy(xpath="//h1[normalize-space()='Your Account Has Been Created!']") WebElement msgConfirmation;

    public void setFirstname(String firstname) {txtFirstname.sendKeys(firstname);}
    public void setLastname(String lastname) {txtlastname.sendKeys(lastname);}
    public void setEmail(String email) {txtEmail.sendKeys(email);}
    public void setTelephone(String telephone) {txtTelephone.sendKeys(telephone);}
    public void setPassword(String password) {txtPassword.sendKeys(password);}
    public void setConfirmPassword(String confirmpassword) {txtConfirmpassword.sendKeys(confirmpassword);}
    public void clickAgree() {txtAgree.click();}
    public void clickButton() {btnContinue.click();}
    
    public String getConfirmationMsg() {
    	try {
    		return (msgConfirmation.getText());
    	}catch(Exception e) {
    		return(e.getMessage());
    	}
    }
}
