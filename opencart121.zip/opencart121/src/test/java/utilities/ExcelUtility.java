package utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtility {

	public static FileInputStream fi;
	public static FileOutputStream fo;
	public static XSSFWorkbook wb;
	public static XSSFSheet ws;
	public static XSSFRow row;
	public static XSSFCell cell;
	public static CellStyle style;
	
	 String path;
	public ExcelUtility(String path)
	{
		this.path=path;
	}
	
	public  int getRowCount( String sheet) throws IOException {
		fi=new FileInputStream(path);
		wb=new XSSFWorkbook(fi);
		ws=wb.getSheet(sheet);
		int rowcount=ws.getLastRowNum();
		wb.close();
		fi.close();
		return rowcount;
	}
	
	public  int getCellCount(String sheet,int rownum) throws IOException {
		fi=new FileInputStream(path);
		wb=new XSSFWorkbook(fi);
		ws=wb.getSheet(sheet);
		row=ws.getRow(1);
		int colcount=row.getLastCellNum();
		wb.close();
		fi.close();
		return colcount;
	}
 public  String getCellData(String sheet, int rownum, int colnum) throws IOException {
	 fi=new FileInputStream(path);
		wb=new XSSFWorkbook(fi);
		ws=wb.getSheet(sheet);
		row=ws.getRow(rownum);
		cell=row.getCell(colnum);
		
		String data;
		//in case of empty cell exception can be thrown so we used try catch block.
		try {
			//data=cell.toString();
			
			  DataFormatter formatter=new DataFormatter();
			  //returns the formatted data in string type irrespective of cell type 
			  data= formatter.formatCellValue(cell);
			 
		}
		catch(Exception e) {
			data="";
			}
		
		wb.close();
		fi.close();
		return data;
	   }
 public static void setCellData(String xfile,String sheet,int rownum,int colnum,String data) throws IOException {
		fi=new FileInputStream(xfile);
		wb=new XSSFWorkbook(fi);
		ws=wb.getSheet(sheet);
		row=ws.getRow(1);
		cell=row.getCell(colnum);
		cell.setCellValue(data);
		fo=new FileOutputStream(xfile);
		wb.write(fo);
		wb.close();
		fi.close();
		fo.close();
	  }
 public static void fillGreenColor(String xfile,String sheet,int rownum,int colnum) throws IOException {
		fi=new FileInputStream(xfile);
		wb=new XSSFWorkbook(fi);
		ws=wb.getSheet(sheet);
		row=ws.getRow(1);
		cell=row.getCell(colnum);
		style=wb.createCellStyle();
		style.setFillForegroundColor(IndexedColors.GREEN.getIndex());
		style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		cell.setCellStyle(style);
		fo=new FileOutputStream(xfile);
		wb.write(fo);
		wb.close();
		fi.close();
		fo.close();
	  }
 
 
 
}
