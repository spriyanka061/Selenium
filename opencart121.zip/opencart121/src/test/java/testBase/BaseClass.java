package testBase;

import java.io.FileReader;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.lang3.RandomStringUtils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import io.github.bonigarcia.wdm.WebDriverManager;


import org.apache.logging.log4j.LogManager;//log4j
import org.apache.logging.log4j.Logger;//log4j


public class BaseClass {
public WebDriver driver;
public Logger logger;
public Properties p;



  @BeforeTest
  
  public void setup() throws InterruptedException, IOException { 
	  logger=LogManager.getLogger(this.getClass());//log4j2
	//config.properties file access 
	  //loading config.properties file 
	  FileReader file=new FileReader("./src//test//resources//config.properties");
	  //to load file
	  p=new Properties();
	  p.load(file);
		
		
		  WebDriverManager.chromedriver().setup(); 
		  driver=new ChromeDriver();
		  driver.manage().deleteAllCookies();
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  driver.manage().window().maximize();
		  driver.get("https://demo.opencart.com/");
		 
		/*
		 * System.setProperty("webdriver.gecko.driver",
		 * "D:\\Browser_drivers\\geckodriver.exe"); driver=new FirefoxDriver();
		 * driver.manage().deleteAllCookies();
		 * driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		 * driver.manage().window().maximize();
		 * driver.get("https://demo.opencart.com/");
		 */
  
//for cross browser testing
	
/*
 * @BeforeTest
 * 
 * @Parameters({"os","br"}) public void setup(String os, String br) throws
 * IOException, InterruptedException { //config.properties file access //loading
 * config.properties file FileReader file=new
 * FileReader("./src//test//resources//config.properties"); //to load file p=new
 * Properties(); p.load(file);
 * 
 * logger=LogManager.getLogger(this.getClass());//log4j2
 * switch(br.toLowerCase()) { case
 * "chrome":{WebDriverManager.chromedriver().setup();driver=new ChromeDriver();
 * break;} case "firefox":{ System.setProperty("webdriver.gecko.driver",
 * "D:\\Browser_drivers\\geckodriver.exe"); driver=new FirefoxDriver(); break;}
 * default:System.out.println("Invalid browser name..."); return; }
 
	  driver.manage().deleteAllCookies();
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  driver.manage().window().maximize();
	  
 */
	   //System.out.println("url="+p.getProperty("appURL2"));
	 // driver.get(p.getProperty("appURL1")); //reading properties file to capture url value.
	  //Thread.sleep(2000);
	  }//setup
   
		/*
		 * @AfterClass public void tearDown() { driver.quit(); }
		 */
	@SuppressWarnings("deprecation")
	public String randomString() {
		String generatedstring=RandomStringUtils.randomAlphabetic(5);
		return generatedstring;
	}
	public String randomNumber() {
		String randomNumeric=RandomStringUtils.randomNumeric(10);
		return randomNumeric;
	}
	public String randomAlphanumeric() {
		String randomString=RandomStringUtils.randomAlphabetic(5);
		String randomNumber=RandomStringUtils.randomNumeric(5);
		
		String randomAlphanumeric=randomString+"@"+randomNumber;
		return randomAlphanumeric;
	}
	
}
